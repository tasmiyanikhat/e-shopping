import { useState, useEffect } from "react";

const ProductList = () =>{
        let[allproduct, updateProduct] = useState( [] );
        const getProduct = () =>{
            fetch("http://localhost:1234/product")
            .then(response=>response.json())
            .then(productArray=>{
                updateProduct(productArray);
            })
        }

        useEffect(()=>{
            getProduct();
        }, []);

        let[keyword, updateKeyword] = useState("");
    return(
        <div className="container mt-5">
            <div className="row mb-4">
                <div className="col-lg-8 text-center">
                    <h3 className="text-primary"> Product in Stock : {allproduct.length} </h3>
                </div>
                <div className="col-lg-4">
                    <i> Search </i>
                    <input type="text" className="form-control" onChange={obj=>updateKeyword(obj.target.value)}/>
                </div>
            </div>
            <div className="row text-center mt-5">
                {
                    allproduct.map((product, index)=>{
                        if(product.pname.toLowerCase().match(keyword.toLowerCase()))
                        return(
                            <div className="col-lg-2 mb-4" key={index}>
                                <h4> {product.pname} </h4>
                                <img src={product.photo} height="150" width="80%"/>
                                <p>Cost : {product.price} </p>
                                <p> {product.details} </p>
                            </div>
                        )
                    })
                }
            </div>
        </div>
    )
}

export default ProductList;