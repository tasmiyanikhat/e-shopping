import { useState } from "react";
import swal from "sweetalert";


const NewProduct = () =>{
    let[prodname, pickName] = useState("");
    let[prodprice, pickPrice] = useState("");
    let[prodphoto, pickPhoto] = useState("");
    let[proddetails, pickDetails] = useState("");

    const save = () =>{
        let url = "http://localhost:1234/product";
        let newproduct = {pname:prodname, price:prodprice, photo:prodphoto, details:proddetails};
        let postdata = {
            headers:{'content-type':'application/json'},
            method:'post',
            body:JSON.stringify(newproduct)
        }
        fetch(url, postdata)
        .then(response=>response.json())
        .then(pinfo=>{
            swal(newproduct.pname+" Uploaded", "New Product Uploaded Successfully", "success");
            pickName(""); pickPrice(""); pickPhoto(""); pickDetails("");
        })
    }

    return(
        <div className="container mt-5">
            <div className="row">
                <div className="col-lg-12 text-center text-primary mb-4">
                    <h3> Enter Product Details </h3>
                </div>

                <div className="col-lg-4 mb-4">
                    <p> Enter Product Name </p>
                    <input type="text" className="form-control"
                    onChange={obj=>pickName(obj.target.value)} value={prodname} />
                </div>

                <div className="col-lg-4 mb-4">
                    <p> Enter Product Price </p>
                    <input type="number" className="form-control"
                    onChange={obj=>pickPrice(obj.target.value)} value={prodprice} />
                </div>

                <div className="col-lg-4 mb-4">
                    <p> Enter Product Photo URL </p>
                    <input type="text" className="form-control"
                    onChange={obj=>pickPhoto(obj.target.value)} value={prodphoto} />
                </div>
                <div className="col-lg-8 mb-4">
                    <p> Enter Product Details </p>
                    <textarea className="form-control" onChange={obj=>pickDetails(obj.target.value)} value={proddetails} ></textarea>
                </div>
                <div className="col-lg-4 mb-4 pt-5 text-center">
                    <button className="btn btn-danger" onClick={save}> Upload Product </button>
                </div>
            </div>
        </div>
    )
}

export default NewProduct;