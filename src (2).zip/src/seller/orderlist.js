import { useState, useEffect } from "react";

const OrderList = () =>{
    let[allorder,updateOrder] =useState([]);
    const getOrder = () =>{
        fetch("http://localhost:1234/order")
            .then(response => response.json())
            .then(orderArray => {
                updateOrder(orderArray);
            })
    }

    useEffect(()=>{
        getOrder();
    },[]);

    let[keyword, updateKeyword] = useState("");

    return(
        <div className="container mt-5">
            <div className="row mb-4">
                <div className="col-lg-8 text-center">
                    <h3 className="text-primary"> Received Order : {allorder.length} </h3>
                </div>
                <div className="col-lg-4">
                    <i> Search </i>
                    <input type="text" className="form-control"  onChange={obj=>updateKeyword(obj.target.value)}/>
                </div>
            </div>
            {
                allorder.map((order, index)=>{
                    if(order.customername.toLowerCase().match(keyword.toLowerCase()) || order.mobileno.toString().match(keyword.toLowerCase()) )
                    return(
                        <div className="row mb-5" key={index}>
                            <div className="col-lg-3">
                                <h4> {order.customername} </h4>
                                <p> Mobile : {order.mobileno} </p>
                                <p> Address : {order.address} </p>
                            </div>
                            <div className="col-lg-9">
                            <table className="table table-bordered">
                                <thead>
                                    <tr>
                                        <th>Item Name</th>
                                        <th>Photo</th>
                                        <th>Price</th>
                                        <th>Quantity</th>
                                        <th>Total</th>
                                    </tr>
                                </thead>
                            <tbody>
                                {
                                    order.itemlist.map((product, index2)=>{
                                        return(
                                            <tr key={index2}>
                                                <td> {product.pname} </td>
                                                <td> <img src={product.photo} height="50" width="50"/> </td>
                                                <td> {product.price} </td>
                                                <td> {product.qty} </td>
                                                <td> {product.price * product.qty} </td>
                                            </tr>
                                        )
                                    })
                                }
                            </tbody>
                        </table>
                            </div>
                        </div>
                    )
                
                })
            }
        </div>
    )
}
export default OrderList;