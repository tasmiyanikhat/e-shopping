import {useState, useEffect} from 'react';
import swal from 'sweetalert';
import ReactPaginate from "react-paginate";

const Myhome = () =>{
    let[allproduct, updateProduct] = useState( [] );
    const getProduct = () =>{
        fetch("http://localhost:1234/product")
        .then(response=>response.json())
        .then(productArray=>{
            updateProduct(productArray.reverse());
        })
    }

    useEffect(()=>{
        getProduct();
    }, []);

    let[keyword, updateKeyword] = useState("");

    const addToCart = (product) =>{
        product["qty"] = 1;
        let url = "http://localhost:1234/cart";
        let postData = {
            headers:{'Content-Type':'application/json'},
            method:'post',
            body:JSON.stringify(product)
        }
        fetch(url, postData)
        .then(response=>response.json())
        .then(productinfo=>{
            swal(product.pname , " Added in Your Cart", "success");
        })
    }


    const PER_PAGE = 2;
    const [currentPage, setCurrentPage] = useState(0);
    function handlePageClick({ selected: selectedPage }) {
        setCurrentPage(selectedPage)
    }
    const offset = currentPage * PER_PAGE;
    const pageCount = Math.ceil(allproduct.length / PER_PAGE);

    return(
        <div className='container mt-4'>
            <div className='row'>
                <div className='col-lg-3'></div>
                <div className='col-lg-6'>
                    <div className='input-group'>
                        <label className='input-group-text'>
                            <i className='fa fa-search'></i>
                        </label>
                        <input type="text" className='form-control' 
                        placeholder={`Search in ${allproduct.length} items`}
                        onChange={obj=>updateKeyword(obj.target.value)}/>
                    </div>
                </div>
                <div className='col-lg-3'></div>
            </div>

            <div className='row mt-5'>
                {
                    allproduct.slice(offset, offset + PER_PAGE).map((product, index)=>{
                        if( product.pname.toLowerCase().match(keyword.toLowerCase()) || 
                            product.details.toLowerCase().match(keyword.toLowerCase()) || 
                            product.price.toString().match(keyword.toLowerCase()) )
                        return(
                            <div className='col-lg-3 mb-4 text-center' key={index}>
                                <div className='p-2'>
                                    <h3 className='text-primary mb-3'> {product.pname} </h3>
                                    <img src={product.photo} height="160" width="100%"/>
                                    <p className='mt-2 text-info'> <b>Rs. {product.price} </b> </p>
                                    <p> {product.details.slice(0,35)}... </p>
                                    <p className='text-center'>
                                        <button className='btn btn-info btn-sm'
                                        onClick={addToCart.bind(this, product)}> Add to Cart </button>
                                    </p>
                                </div>
                            </div>
                        )
                    })
                }
            </div>

            <div className="mb-4 mt-4">
                <ReactPaginate
                    previousLabel={"Previous"}
                    nextLabel={"Next"}
                    breakLabel={"..."}
                    pageCount={pageCount}
                    marginPagesDisplayed={2}
                    pageRangeDisplayed={3}
                    onPageChange={handlePageClick}
                    containerClassName={"pagination  justify-content-center"}
                    pageClassName={"page-item "}
                    pageLinkClassName={"page-link"}
                    previousClassName={"page-item"}
                    previousLinkClassName={"page-link"}
                    nextClassName={"page-item"}
                    nextLinkClassName={"page-link"}
                    breakClassName={"page-item"}
                    breakLinkClassName={"page-link"}
                    activeClassName={"active primary"}
                />
            </div>
        </div>
    )
}
export default Myhome;