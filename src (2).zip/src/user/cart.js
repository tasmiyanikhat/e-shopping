import { useState, useEffect } from "react";
import swal from "sweetalert";

const Mycart = () =>{
    let[allproduct, updateProduct] = useState( [] );
    const getProduct = () =>{
        fetch("http://localhost:1234/cart")
        .then(response=>response.json())
        .then(productArray=>{
            updateProduct(productArray.reverse());
        })
    }

    useEffect(()=>{
        getProduct();
    }, []);

    const delCart = (id) =>{
        let url = "http://localhost:1234/cart/"+id;
        let postData = {method:"delete"};
        fetch(url, postData)
        .then(response=>response.json())
        .then(pinfo=>{
            swal(pinfo.pname, "Deleted From Your Cart", "info");
            getProduct();
        })
    }

    const updateQty = (product, status) =>{
        if(status==="A"){
            product["qty"] = product.qty + 1;
        }else{
            product["qty"] = product.qty - 1; 
        }

        if(product.qty==0){
            delCart(product.id);
        }else{
        let url = "http://localhost:1234/cart/"+product.id;
        let postData = {
            headers:{'Content-Type':'application/json'},
            method:"put",
            body:JSON.stringify(product)
        }
        fetch(url, postData)
        .then(response=>response.json())
        .then(pinfo=>{
            getProduct();// reload the list after update of quantity
        })
     }
    }

    let[fullname, pickName] = useState("");
    let[mobile, pickMobile] = useState("");
    let[address, pickAddress] = useState("");

    const placeOrder = async() =>{
        let orderData = {
            customername:fullname,
            mobileno:mobile,
            address:address,
            itemlist:allproduct
        }
        let url = "http://localhost:1234/order";
        let postData = {
            headers:{'Content-Type':'application/json'},
            method:"POST",
            body:JSON.stringify(orderData) // object to json
        }

        await fetch(url, postData)
        .then(response=>response.json())
        .then(orderinfo=>{
            swal("Hi "+fullname , "We Received Your Order", "info");
        })
    }

    return(
        <div className="container mt-4">
            <div className="row">
                <div className="col-lg-4"></div>
                <div className="col-lg-4">
                    <h3 className="text-center text-primary">  
                        <i className="fa fa-shopping-cart"></i> Items in your Cart : {allproduct.length} 
                    </h3>
                </div>
                <div className="col-lg-4"></div>
            </div>
            <div className="row mt-4">
                <div className="col-lg-3">
                    <h3> Enter Customer Details </h3>
                    <div className="mb-4">
                        <p> Customer Name </p>
                        <input type="text" className="form-control" onChange={obj=>pickName(obj.target.value)} value={fullname}/>
                    </div>
                    <div className="mb-4">
                        <p> Customer Mobile No </p>
                        <input type="number" className="form-control" onChange={obj=>pickMobile(obj.target.value)} value={mobile}/>
                    </div>
                    <div className="mb-4">
                        <p> Full Address </p>
                        <textarea className="form-control" onChange={obj=>pickAddress(obj.target.value)} value={address}></textarea>
                    </div>
                    <div className="text-center">
                        <button className="btn btn-danger" onClick={placeOrder}> Place Order </button>
                    </div>
                </div>
                <div className="col-lg-9">
                    <table className="table table-bordered">
                        <thead>
                            <tr>
                                <th>Item Name</th>
                                <th>Photo</th>
                                <th>Price</th>
                                <th>Quantity</th>
                                <th>Total</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            {
                                allproduct.map((product, index)=>{
                                    return(
                                        <tr key={index}>
                                            <td> {product.pname} </td>
                                            <td> <img src={product.photo} height="50" width="50"/> </td>
                                            <td> {product.price} </td>
                                            <td> 
                                                <button className="btn btn-warning me-2" onClick={updateQty.bind(this, product, "B")}> - </button>
                                                    {product.qty} 
                                                <button className="btn btn-info ms-2" onClick={updateQty.bind(this, product, "A")}> + </button>
                                            </td>
                                            <td> {product.price * product.qty} </td>
                                            <td> 
                                                <i className="fa fa-trash fa-lg text-danger" onClick={delCart.bind(this, product.id)}></i>
                                            </td>
                                        </tr>
                                    )
                                })
                            }
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    )
}

export default Mycart;