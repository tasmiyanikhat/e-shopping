
import { HashRouter, Routes, Route, Link } from "react-router-dom";
import Myhome from "./home";
import Mycart from "./cart";
import Mylogin from "./login";

const UserModule = () =>{
    return(
            <HashRouter>
             <nav className="navbar navbar-expand-sm navbar-dark bg-dark sticky-top p-3">
                <div className="container">
                    <a className="navbar-brand">
                        <i className="fa fa-shopping-bag fa-lg text-warning"></i> React Shopping
                    </a>
                    <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#mynavbar">
                        <span className="navbar-toggler-icon"></span>
                    </button>
                    <div className="collapse navbar-collapse" id="mynavbar">
                      <ul className="navbar-nav ms-auto">
                        <li className="nav-item me-3">
                            <Link className="nav-link active" to="/"> 
                                <i className="fa fa-home"></i> Home
                            </Link>
                        </li>
                        <li className="nav-item me-3">
                            <Link className="nav-link active" to="/cart"> 
                                <i className="fa fa-shopping-cart"></i> My Cart
                            </Link>
                        </li>
                        <li className="nav-item me-3">
                            <Link className="nav-link active" to="/login"> 
                                <i className="fa fa-lock"></i> Seller Login
                            </Link>
                        </li>
                      </ul>
                    </div>
                </div>
            </nav>
            <Routes>
                <Route exact path="/" element={ <Myhome/> }/>
                <Route exact path="/cart" element={ <Mycart/> }/>
                <Route exact path="/login" element={ <Mylogin/> }/>
            </Routes>
            
        </HashRouter>
    )
}

export default UserModule;