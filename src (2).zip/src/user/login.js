import { useState } from "react";

const Mylogin = () =>{
    return(
        <div className="container mt-5">
            <div className="row">
                <div className="col-lg-4"></div>
                <div className="col-lg-4">
                    <div className="border rounded p-3">
                        <h2 className="text-center text-primary">  <i className="fa fa-lock"></i> Login </h2>
                        <div className="mb-3">
                            <p>e-Mail id</p>
                            <input type="text" className="form-control"/>
                        </div>
                        <div className="mb-3">
                            <p>Password</p>
                            <input type="password" className="form-control"/>
                        </div>
                        <div className="text-center">
                            <button className="btn btn-danger"> 
                                Login <i className="fa fa-arrow-right"></i> 
                            </button>
                        </div>
                    </div>
                </div>
                <div className="col-lg-4"></div>
            </div>
        </div>
    )
}

export default Mylogin;